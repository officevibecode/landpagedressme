<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "=== Teste de Configuração do Stripe ===\n\n";

require_once 'config.php';
require_once 'stripe-php/autoload.php';

echo "1. Config carregado\n";
echo "   STRIPE_SECRET_KEY: " . (defined('STRIPE_SECRET_KEY') ? 'DEFINIDA' : 'NÃO DEFINIDA') . "\n";
echo "   STRIPE_PUBLISHABLE_KEY: " . (defined('STRIPE_PUBLISHABLE_KEY') ? 'DEFINIDA' : 'NÃO DEFINIDA') . "\n\n";

echo "2. Testando conexão com Stripe...\n";
try {
    \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
    echo "   API Key configurada\n\n";
    
    echo "3. Tentando criar sessão de checkout...\n";
    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'eur',
                'product_data' => [
                    'name' => 'Teste DressMe',
                ],
                'unit_amount' => 151500,
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => 'http://localhost:3002/success.html?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => 'http://localhost:3002/cancel.html',
    ]);
    
    echo "   ✅ SUCESSO! Sessão criada:\n";
    echo "   ID: " . $session->id . "\n";
    echo "   URL: " . $session->url . "\n";
    echo "\n=== TUDO FUNCIONANDO! ===\n";
    
} catch (Exception $e) {
    echo "   ❌ ERRO: " . $e->getMessage() . "\n";
    echo "   Tipo: " . get_class($e) . "\n";
}

