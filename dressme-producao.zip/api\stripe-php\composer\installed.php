<?php return array(
    'root' => array(
        'name' => 'tgoo/dressme-api',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => '8d887aabd823f675337ba9e1021b6f469778e7ad',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'stripe/stripe-php' => array(
            'pretty_version' => 'v13.18.0',
            'version' => '13.18.0.0',
            'reference' => '02abb043b103766f4ed920642ae56ffdc58c7467',
            'type' => 'library',
            'install_path' => __DIR__ . '/../stripe/stripe-php',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'tgoo/dressme-api' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => '8d887aabd823f675337ba9e1021b6f469778e7ad',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
